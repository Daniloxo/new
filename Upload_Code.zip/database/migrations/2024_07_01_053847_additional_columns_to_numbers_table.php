<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::table('numbers', function (Blueprint $table) {
            $table->string('page_title')->nullable()->default(null)->after('status');
            $table->text('custom_header')->nullable()->default(null)->after('page_title');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::table('numbers', function (Blueprint $table) {
            $table->dropColumn(['page_title', 'custom_header']);
        });
    }
};
