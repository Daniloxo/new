<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::table('orders', function (Blueprint $table) {
            $table->unsignedInteger('max_messages')->after('number_id')->default(0);
            $table->unsignedInteger('messages_received')->after('number_id')->default(0);
            $table->unsignedTinyInteger('status')->after('expiry')->default(1); //1 - Active//0 - Expired
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn(['max_messages', 'messages_received', 'status']);
        });
    }
};
