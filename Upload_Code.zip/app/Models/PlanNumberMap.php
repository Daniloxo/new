<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PlanNumberMap extends Model {
    use HasFactory;

    public function plan() {
        return $this->belongsTo('App\Models\Plan');
    }

    public function number() {
        return $this->belongsTo('App\Models\Number');
    }
}
