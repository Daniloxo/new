<?php

namespace App\Http\Controllers;

use App\Services\RazorPay;
use App\Services\Stripe;
use App\Models\WalletTransaction;
use App\Services\CoinPayments;
use App\Services\PayPal;
use App\Services\Paystack;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class PaymentController extends Controller {

    public function initiatePayPal(Request $request) {
        if (session('amount', 0) == 0) {
            return redirect()->route('wallet');
        }
        $paypal = PayPal::initiate(session('amount'));
        $request->session()->forget('amount');
        return view('common.paypal')->with(compact('paypal'));
    }

    public function process($id, $status, Request $request) {
        $transaction = WalletTransaction::findOrFail($id);
        if ($transaction->payment_method == 'stripe') {
            $process = Stripe::process($id, $status);
            if (isset($process['success'])) {
                Session::flash('success', $process['success']);
            } else if (isset($process['error'])) {
                Session::flash('error', $process['error']);
            }
            return redirect()->route('wallet');
        } else if ($transaction->payment_method == 'razorpay') {
            $process = RazorPay::process($id, $request->get('razorpay_payment_id'), $request->get('razorpay_signature'));
            if (isset($process['success'])) {
                Session::flash('success', $process['success']);
            } else if (isset($process['error'])) {
                Session::flash('error', $process['error']);
            }
            return redirect()->route('wallet');
        } else if ($transaction->payment_method == 'paypal') {
            $process = PayPal::process($id, $status, $request->get('paypal_order_id'));
            if (isset($process['success'])) {
                Session::flash('success', $process['success']);
            } else if (isset($process['error'])) {
                Session::flash('error', $process['error']);
            }
            return redirect()->route('wallet');
        } else if ($transaction->payment_method == 'coinpayments') {
            $process = CoinPayments::process($id, $status);
            if (isset($process['success'])) {
                Session::flash('success', $process['success']);
            } else if (isset($process['error'])) {
                Session::flash('error', $process['error']);
            }
            return redirect()->route('wallet');
        } else if ($transaction->payment_method == 'paystack') {
            $process = Paystack::process($id, $status);
            if (isset($process['success'])) {
                Session::flash('success', $process['success']);
            } else if (isset($process['error'])) {
                Session::flash('error', $process['error']);
            }
            return redirect()->route('wallet');
        }
    }
}
