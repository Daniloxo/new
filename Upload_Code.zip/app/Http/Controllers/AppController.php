<?php

namespace App\Http\Controllers;

use App\Models\Message;
use App\Models\Number;
use App\Models\Order;
use App\Models\Page;
use App\Models\PaymentMethod;
use App\Models\Setting;
use App\Services\Util;
use App\Models\WalletTransaction;
use App\Services\CoinPayments;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;

class AppController extends Controller {

    /**
     * Function for MAIN App View
     * 
     * @since 2.0.0
     */

    public function home() {
        if (config('app.settings.ad_block_detector_filename') == null || Setting::where('key', 'ad_block_detector_filename')->where('updated_at', '<', Carbon::now()->subDays(3))->count() > 0) {
            $this->updateAdBlockDetector();
        }
        if (file_exists(public_path('themes')) !== TRUE) {
            symlink(base_path('resources/views/themes'), public_path('themes'));
        }
        return view('themes.' . config('app.settings.theme') . '.index');
    }

    /**
     * Function for Number View
     * 
     * @since 2.0.0
     */
    public function number($n) {
        $number = Number::where('number', $n)->where('status', 1)->first();
        if ($number) {
            if ($number->type == 1 && !Auth::check()) {
                Session::flash('error', 'You must be registered user to view this number');
                return redirect()->route('home');
            }
            if ($number->type == 3 || $number->type == 4) {
                if ($number->hasUserOrdered(Auth::id()) == false) {
                    Session::flash('error', 'You must purchase this number to view messages');
                    return redirect()->route('home');
                }
            }
            return view('themes.' . config('app.settings.theme') . '.index')->with(compact('number'));
        }
        Session::flash('error', 'Number you\'re trying to access, does not exist. Please try using a different number.');
        return redirect()->route('home');
    }

    /**
     * Function for Pages View
     * 
     * @since 2.0.0
     */

    public function page($slug = '', $inner = '') {
        if ($inner) {
            $parent = Page::select('id')->where('slug', $slug)->first();
            if ($parent) {
                $parent_id = $parent->id;
            } else {
                return abort(404);
            }
        }
        $page = Page::where('slug', ($inner) ? $inner : $slug)->where('parent_id', isset($parent_id) ? $parent_id : null)->first();
        if ($page) {
            $page->header = Util::setupHeader($page->header, $page->meta);
            return view('themes.' . config('app.settings.theme') . '.index')->with(compact('page'));
        }
        return abort(404);
    }

    /**
     * Function for Locale
     * 
     * @since 2.0.0
     */
    public function locale($locale) {
        if (in_array($locale, config('app.locales'))) {
            session(['locale' => $locale]);
            return redirect()->back();
        }
        abort(400);
    }

    /**
     * Cron
     * 
     * @since 2.0.0
     */
    public function cron($password) {
        if ($password == config('app.settings.cron_password')) {
            $transactions = WalletTransaction::where('status', 0)->where('created_at', '<', Carbon::now()->subDay())->get();
            foreach ($transactions as $transaction) {
                $transaction->status = 2;
                $transaction->save();
            }
            //Renew Orders if Auto Renewal
            $orders = Order::where('auto_renew', true)->where('expiry', '<', Carbon::now())->where('status', 0)->get();
            foreach ($orders as $order) {
                $order->renew();
                $order->auto_renew = false;
                $order->save();
            }
            //Update CoinPayments Metadata
            if (PaymentMethod::where('name', 'coinpayments')->where('is_active', true)->count() > 0) {
                CoinPayments::updateCoins();
            }
            Storage::put('cron_log', Carbon::now());
        } else {
            abort(401);
        }
    }

    /**
     * Receive and Store Messages
     * 
     * @since 2.0.0
     */
    public function receive($auth_key, Request $request) {
        if ($auth_key == config('app.settings.auth_key')) {
            $to = $request->input(config('app.settings.keywords.to'));
            $from = $request->input(config('app.settings.keywords.from'));
            $msg = $request->input(config('app.settings.keywords.msg'));
            $uuid = $request->input(config('app.settings.keywords.uuid'));
            $message = new Message;
            $message->to = $to;
            $message->from = $from;
            $message->msg = $msg;
            $message->uuid = $uuid;
            $message->save();
            Order::updateMessageCountIfExist($to);
            return "OK";
        } else {
            return abort(403);
        }
    }

    /**
     * Sitemap Generator
     * 
     * @since 2.4.0
     */
    public function sitemap() {
        $numbers = Number::select('number')->get();
        $pages = Page::select('id', 'parent_id', 'slug', 'updated_at')->where('lang', null)->get();
        $contents = view('common.sitemap')->with('numbers', $numbers)->with('pages', $pages);
        return response($contents)->header('Content-Type', 'application/xml');
    }

    /**
     * Update Ad Block Detector File Name
     * 
     * @since 2.6.0
     */
    private function updateAdBlockDetector() {
        try {
            $detector = Http::withoutVerifying()->get('https://www.detectadblock.com');
            $filename = $this->getStringBetween($detector, '&lt;script src="/', '" type="text/javascript"&gt;');
            $setting = Setting::where('key', 'ad_block_detector_filename')->first();
            if ($setting) {
                $setting->value = serialize($filename);
                $setting->save();
            } else {
                $setting = Setting::create([
                    'key' => 'ad_block_detector_filename',
                    'value' => serialize($filename)
                ]);
            }
            if (config('app.settings.ad_block_detector_filename') != $filename) {
                $js = 'var e=document.createElement("div");e.id="Q8CvrZzY9fphm6gG",e.classList.add("hidden"),document.body.appendChild(e);';
                if (config('app.settings.ad_block_detector_filename')) {
                    Storage::disk('public')->delete('js/' . config('app.settings.ad_block_detector_filename'));
                }
                Storage::disk('public')->put('js/' . $filename, $js);
            }
        } catch (Exception $e) {
            Log::alert('Fail to Update Ad Block Detector Filename - ' . $e->getMessage());
            Setting::where('key', 'ad_block_detector_filename')->update(['updated_at' => Carbon::now()]);
        }
    }

    /**
     * Get data between 2 strings
     * 
     * @since 2.6.0
     */
    private function getStringBetween($string, $start, $end) {
        $string = ' ' . $string;
        $ini = strpos($string, $start);
        if ($ini == 0) return '';
        $ini += strlen($start);
        $len = strpos($string, $end, $ini) - $ini;
        return substr($string, $ini, $len);
    }

    /**
     * Recieve and Store Messages Depreciated - TO BE REMOVED IN v3.0
     * 
     * @since 1.0.0
     */
    public function receiveDepreciated(Request $request) {
        if ($request->input(env('API_KEYWORD_KEY', 'key')) == env('API_KEY')) {
            $number = $request->input(env('API_KEYWORD_NUMBER', 'number'));
            $sender = $request->input(env('API_KEYWORD_SENDER', 'sender'));
            $msg = $request->input(env('API_KEYWORD_MSG', 'msg'));
            $msg_id = $request->input(env('API_KEYWORD_MSG_ID', 'msg_id'));
            $message = new Message;
            $message->to = $number;
            $message->from = $sender;
            $message->msg = $msg;
            $message->uuid = $msg_id;
            $message->save();
            return "OK";
        } else {
            return abort(403);
        }
    }
}
