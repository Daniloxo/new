<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class BanMiddleware {
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next) {
        if (auth()->check() && auth()->user()->role == 2) {
            auth()->logout();
            return redirect()->route('login')->withErrors(['banned' => __('Your account has been banned.')]);
        }
        return $next($request);
    }
}
