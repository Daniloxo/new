@extends('themes.' . config('app.settings.theme') . '.layout')

@section('header')
    @if(isset($number))
    {!! $number->custom_header !!}
    @endif
    @if(isset($page))
    {!! $page->header !!}
    <title>{{ $page->title }} - {{ config('app.settings.name') }}</title>
    @elseif(isset($number) && $number->page_title != null && trim($number->page_title))
    <title>{{ $number->page_title }} - {{ config('app.settings.name') }}</title>
    @elseif(isset($number) && $number->page_title != null && trim($number->page_title) == '')
    <title>{{ config('app.settings.name') }}</title>
    @elseif(isset($number) && $number->page_title === null)
    <title>Messages for +{{ $number->number }} - {{ config('app.settings.name') }}</title>
    @else
    <title>{{ config('app.settings.name') }}</title>
    @endif
    @if(!isset($page) && !isset($number))
    {!! config('app.settings.homepage.header') !!}
    @endif
@endsection

@section('content')
    @if(isset($page))
    @livewire('frontend.page', ['page' => $page])
    @elseif(isset($number))
    @livewire('frontend.number', ['number' => $number])
    @else
    @livewire('frontend.home')
    @endif
@endsection

@section('footer')
    @if(!isset($page) && !isset($number))
    {!! config('app.settings.homepage.footer') !!}
    @endif
@endsection